var express = require('express')
var app = express()
const PORT = process.env.PORT || 5000
const mysql = require('mysql')
const path = require('path');

var connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "password",
    database: "mydb"
});

connection.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
});

app.use(express.static(path.join(__dirname, 'client/build')));

app.get('/api/getEmployees', function (req, res) {
    connection.query('SELECT * FROM Employee', function (err, results) {
        (err) ? res.send(err) : res.end(JSON.stringify(results));
    })
})
app.delete(`/api/deleteEmployees/:id`, function (req, res) {
    var emplid = req.params.id;
    connection.query(`DELETE FROM Employee WHERE emplid = ${emplid}`, function (err, results) {
        (err) ? res.send(err) : res.end(JSON.stringify(results));
    })
})
const bodyParser = require("body-parser");

/** bodyParser.urlencoded(options)
 * Parses the text as URL encoded data (which is how browsers tend to send form data from regular forms set to POST)
 * and exposes the resulting object (containing the keys and values) on req.body
 */
app.use(bodyParser.urlencoded({
    extended: true
}));

/**bodyParser.json(options)
 * Parses the text as JSON and exposes the resulting object on req.body.
 */
app.use(bodyParser.json());

app.post(`/api/addEmployee`, function (req, res) {
    var fname = req.body.user.first_name;

    var lname = req.body.user.last_name;
    var email = req.body.user.email;
    var phone = req.body.user.phone_number;
    var address = req.body.user.address;
    var hourly = req.body.user.hourly_rate;
    var weekly = req.body.user.total_weekly;
    var title = req.body.user.title;

    connection.query(`INSERT into Employee (first_name,last_name,email,phone_number,address,hourly_rate,total_weekly,title) values('${fname}','${lname}','${email}','${phone}','${address}',${hourly}, ${weekly},'${title}');`, function (err, results) {
        (err) ? res.send(err) : res.end(JSON.stringify(results));
    })
})

app.post(`/api/updateEmployee`, function (req, res) {
    var emplid = req.body.user.emplid;
    var fname = req.body.user.first_name;
    var lname = req.body.user.last_name;
    var email = req.body.user.email;
    var phone = req.body.user.phone_number;
    var address = req.body.user.address;
    var hourly = req.body.user.hourly_rate;
    var weekly = req.body.user.total_weekly;
    var title = req.body.user.title;

    connection.query(`UPDATE Employee SET first_name ='${fname}',last_name= '${lname}', email = '${email}', phone_number = '${phone}', address = '${address}', hourly_rate = ${hourly}, total_weekly = ${weekly} , title = '${title}' WHERE emplid = ${emplid};`, function (err, results) {
        (err) ? res.send(err) : res.end(JSON.stringify(results));
    })
})
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname + '/client/build/index.html'));
});

app.listen(PORT, () => {
    console.log(`App running on port: ${PORT}`)
});